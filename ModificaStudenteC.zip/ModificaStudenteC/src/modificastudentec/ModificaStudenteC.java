/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modificastudentec;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Colombo_alice
 */
public class ModificaStudenteC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        InputStreamReader reader = new InputStreamReader (System.in);
        BufferedReader myInput = new BufferedReader (reader);
         try {
        System.out.println("inserisci l' e-mail da modificare:");
       String mail=myInput.readLine();
       
       
       
       System.out.println("inserisci l' e-mail da modificare:");
       String mail1=myInput.readLine();
       System.out.println("inserisci l' e-mail da modificare:");
       String cognome=myInput.readLine();
       System.out.println("inserisci l' e-mail da modificare:");
       String nome=myInput.readLine();
       System.out.println("inserisci l' e-mail da modificare:");
       String password=myInput.readLine();
       System.out.println("inserisci l' e-mail da modificare:");

       
        } catch (IOException ex) {
            Logger.getLogger(ModificaStudenteC.class.getName()).log(Level.SEVERE, null, ex);
        }
         
    }
    
}
