/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ModificaStudente;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author Colombo_alice
 */
@WebService(serviceName = "Modifica")
public class Modifica {

    /**
     * Web service operation
     */
    @WebMethod(operationName = "Richiesta")
    public String Richiesta(@WebParam(name = "mail") String mail) {
        //TODO write your implementation code here:
         FileReader f;
        try {
            f=new FileReader("Studenti.txt");
            BufferedReader b;
            b=new BufferedReader(f);
             String line;
            
           while(true) {
                line=b.readLine();
                 if(line==null)
                 break;
                String vet[]=line.split(";");
                if(vet[0]==mail)
                    return line;
              }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Modifica.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Modifica.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "no";
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "modifica")
    public String modifica(@WebParam(name = "StringaTot") String StringaTot) {
        //TODO write your implementation code here:
        String Vetp[]=StringaTot.split(";");
         FileReader f;
        try {
            f=new FileReader("Studenti.txt");
            BufferedReader b;
            b=new BufferedReader(f);
             String line;
            
           while(true) {
                line=b.readLine();
                 if(line==null)
                 break;
                String vet[]=line.split(";");
                if(vet[0]!=Vetp[0])
                {
                     try
     {
          FileOutputStream prova = new FileOutputStream("temp.txt");
          PrintStream scrivi = new PrintStream(prova);
          
                scrivi.println(line);
          
      }
      catch (IOException e)
      {
          System.out.println("Errore: " + e);
          System.exit(1);
      }
                }
                else
                {
                     try
     {
          FileOutputStream prova = new FileOutputStream("temp.txt");
          PrintStream scrivi = new PrintStream(prova);
          
                scrivi.println(StringaTot);
                
                
         
          
      }
      catch (IOException e)
      {
          System.out.println("Errore: " + e);
          System.exit(1);
      } 
                }
              }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Modifica.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(Modifica.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    /**
     * Web service operation
     */
  
}
    
    
    
